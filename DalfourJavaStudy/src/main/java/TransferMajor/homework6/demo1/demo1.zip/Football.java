package study.dalfour.zzy.homework6.demo1;

public interface Football extends Sports{

	void homeTeamScored(int homeTeamScore);

}
