package study.dalfour.zzy.homework6.demo1;

public interface Sports {

	void setHomeTeam(String homeTeamName);

	void setVisitingTeam(String visitingTeamName);

}
