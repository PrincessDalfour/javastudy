package study.dalfour.zzy.homework6.demo1;

public interface Hockey extends Sports{

	void endOfPeriod(int finalResult);

}
