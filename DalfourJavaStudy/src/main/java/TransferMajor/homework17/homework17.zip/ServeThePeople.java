package TransferMajor.homework17;

public interface ServeThePeople {
	public abstract void Service();
}
